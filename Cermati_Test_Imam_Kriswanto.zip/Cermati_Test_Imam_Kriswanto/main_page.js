$(document).ready(function(){   
    setTimeout(function () {
        $("#cookieConsent").slideDown();
     }, 2000);
    $("#closeCookieConsent, .cookieConsentOK").click(function() {
        $("#cookieConsent").slideUp();
    }); 
}); 

 $(window).scroll(function() {   
   if($(window).scrollTop() + $(window).height() == $(document).height()) {
        $("#cookieConsent1").slideDown();
   }
   $(".closeButtonNews").click(function() {
        $("#cookieConsent1").slideUp();
    });
});